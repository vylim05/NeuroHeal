package com.example.concussion_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
